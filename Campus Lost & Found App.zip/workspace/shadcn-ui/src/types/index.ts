export interface User {
  id: string;
  email: string;
  name: string;
  studentId?: string;
  phone?: string;
  role: 'student' | 'staff' | 'security';
  createdAt: string;
  isActive: boolean;
  goodSamaritanCount?: number;
}

export interface Item {
  id: string;
  title: string;
  description: string;
  category: ItemCategory;
  location: string;
  dateReported: string;
  dateLostFound?: string;
  status: ItemStatus;
  type: 'lost' | 'found';
  userId?: string;
  images: string[];
  tags: string[];
  contactInfo?: string;
  reward?: number;
  claimedBy?: string;
  claimedAt?: string;
  returnedAt?: string;
  createdAt: string;
  updatedAt: string;
  verificationQuestion?: string;
  verificationAnswer?: string;
}

export interface Claim {
  id: string;
  itemId: string;
  claimantId?: string;
  ownerId?: string;
  status: ClaimStatus;
  description: string;
  proofImages?: string[];
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  verificationAnswer?: string;
  verificationQuestion?: string;
}

export type ItemCategory = 
  | 'electronics'
  | 'clothing'
  | 'accessories'
  | 'books'
  | 'keys'
  | 'bags'
  | 'documents'
  | 'sports'
  | 'other';

export type ItemStatus = 
  | 'active'
  | 'claimed'
  | 'returned'
  | 'expired';

export type ClaimStatus = 
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'completed';

export interface SearchFilters {
  query?: string;
  category?: ItemCategory;
  location?: string;
  type?: 'lost' | 'found';
  dateFrom?: string;
  dateTo?: string;
  status?: ItemStatus;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface AppState {
  auth: AuthState;
  items: Item[];
  claims: Claim[];
  searchFilters: SearchFilters;
  isLoading: boolean;
}

export interface MatchingSuggestion {
  item: Item;
  matchScore: number;
  matchingKeywords: string[];
}