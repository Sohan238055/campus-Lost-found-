import { User, Item, Claim } from '../types';

class DataService {
  private static instance: DataService;
  
  private constructor() {}
  
  static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }

  // Generic localStorage operations
  private getFromStorage<T>(key: string): T[] {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error(`Error reading ${key} from localStorage:`, error);
      return [];
    }
  }

  private saveToStorage<T>(key: string, data: T[]): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error(`Error saving ${key} to localStorage:`, error);
    }
  }

  // User operations
  getUsers(): User[] {
    return this.getFromStorage<User>('lost_found_users');
  }

  saveUser(user: User): void {
    const users = this.getUsers();
    const existingIndex = users.findIndex(u => u.id === user.id);
    
    if (existingIndex >= 0) {
      users[existingIndex] = user;
    } else {
      users.push(user);
    }
    
    this.saveToStorage('lost_found_users', users);
  }

  getUserByEmail(email: string): User | null {
    const users = this.getUsers();
    return users.find(user => user.email === email) || null;
  }

  getUserById(id: string): User | null {
    const users = this.getUsers();
    return users.find(user => user.id === id) || null;
  }

  // Item operations
  getItems(): Item[] {
    return this.getFromStorage<Item>('lost_found_items');
  }

  saveItem(item: Item): void {
    const items = this.getItems();
    const existingIndex = items.findIndex(i => i.id === item.id);
    
    if (existingIndex >= 0) {
      items[existingIndex] = { ...item, updatedAt: new Date().toISOString() };
    } else {
      items.push(item);
    }
    
    this.saveToStorage('lost_found_items', items);
  }

  getItemById(id: string): Item | null {
    const items = this.getItems();
    return items.find(item => item.id === id) || null;
  }

  getItemsByUserId(userId: string): Item[] {
    const items = this.getItems();
    return items.filter(item => item.userId === userId);
  }

  deleteItem(id: string): void {
    const items = this.getItems();
    const filteredItems = items.filter(item => item.id !== id);
    this.saveToStorage('lost_found_items', filteredItems);
  }

  // Claim operations
  getClaims(): Claim[] {
    return this.getFromStorage<Claim>('lost_found_claims');
  }

  saveClaim(claim: Claim): void {
    const claims = this.getClaims();
    const existingIndex = claims.findIndex(c => c.id === claim.id);
    
    if (existingIndex >= 0) {
      claims[existingIndex] = { ...claim, updatedAt: new Date().toISOString() };
    } else {
      claims.push(claim);
    }
    
    this.saveToStorage('lost_found_claims', claims);
  }

  getClaimsByItemId(itemId: string): Claim[] {
    const claims = this.getClaims();
    return claims.filter(claim => claim.itemId === itemId);
  }

  getClaimsByUserId(userId: string): Claim[] {
    const claims = this.getClaims();
    return claims.filter(claim => claim.claimantId === userId || claim.ownerId === userId);
  }

  // Search and filter operations
  searchItems(query: string, items: Item[]): Item[] {
    if (!query.trim()) return items;
    
    const searchTerm = query.toLowerCase();
    return items.filter(item => 
      item.title.toLowerCase().includes(searchTerm) ||
      item.description.toLowerCase().includes(searchTerm) ||
      item.location.toLowerCase().includes(searchTerm) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  }

  // Image operations
  saveImage(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const base64String = reader.result as string;
          resolve(base64String);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  // Utility methods
  generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  clearAllData(): void {
    localStorage.removeItem('lost_found_users');
    localStorage.removeItem('lost_found_items');
    localStorage.removeItem('lost_found_claims');
    localStorage.removeItem('lost_found_auth_token');
  }
}

export default DataService;