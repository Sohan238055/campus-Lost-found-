import { User } from '../types';
import DataService from './DataService';

class AuthService {
  private static instance: AuthService;
  private dataService: DataService;
  
  private constructor() {
    this.dataService = DataService.getInstance();
  }
  
  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async register(userData: {
    email: string;
    password: string;
    name: string;
    studentId?: string;
    phone?: string;
    role: 'student' | 'staff' | 'security';
  }): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      // Check if user already exists
      const existingUser = this.dataService.getUserByEmail(userData.email);
      if (existingUser) {
        return { success: false, error: 'User with this email already exists' };
      }

      // Create new user
      const newUser: User = {
        id: this.dataService.generateId(),
        email: userData.email,
        name: userData.name,
        studentId: userData.studentId,
        phone: userData.phone,
        role: userData.role,
        createdAt: new Date().toISOString(),
        isActive: true
      };

      // Save user and password hash (simplified for localStorage)
      this.dataService.saveUser(newUser);
      this.savePasswordHash(userData.email, userData.password);

      return { success: true, user: newUser };
    } catch (error) {
      return { success: false, error: 'Registration failed' };
    }
  }

  async login(email: string, password: string): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const user = this.dataService.getUserByEmail(email);
      if (!user) {
        return { success: false, error: 'User not found' };
      }

      if (!user.isActive) {
        return { success: false, error: 'Account is deactivated' };
      }

      // Verify password (simplified for localStorage)
      const isValidPassword = this.verifyPassword(email, password);
      if (!isValidPassword) {
        return { success: false, error: 'Invalid password' };
      }

      // Create session token
      const token = this.createToken(user);
      localStorage.setItem('lost_found_auth_token', token);

      return { success: true, user };
    } catch (error) {
      return { success: false, error: 'Login failed' };
    }
  }

  logout(): void {
    localStorage.removeItem('lost_found_auth_token');
  }

  getCurrentUser(): User | null {
    try {
      const token = localStorage.getItem('lost_found_auth_token');
      if (!token) return null;

      const userData = this.parseToken(token);
      if (!userData) return null;

      // Verify user still exists and is active
      const user = this.dataService.getUserById(userData.userId);
      return user && user.isActive ? user : null;
    } catch (error) {
      return null;
    }
  }

  isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  updateProfile(userId: string, updates: Partial<User>): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const user = this.dataService.getUserById(userId);
      if (!user) {
        return Promise.resolve({ success: false, error: 'User not found' });
      }

      const updatedUser = { ...user, ...updates };
      this.dataService.saveUser(updatedUser);

      return Promise.resolve({ success: true, user: updatedUser });
    } catch (error) {
      return Promise.resolve({ success: false, error: 'Profile update failed' });
    }
  }

  changePassword(userId: string, currentPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    try {
      const user = this.dataService.getUserById(userId);
      if (!user) {
        return Promise.resolve({ success: false, error: 'User not found' });
      }

      // Verify current password
      const isValidPassword = this.verifyPassword(user.email, currentPassword);
      if (!isValidPassword) {
        return Promise.resolve({ success: false, error: 'Current password is incorrect' });
      }

      // Save new password
      this.savePasswordHash(user.email, newPassword);

      return Promise.resolve({ success: true });
    } catch (error) {
      return Promise.resolve({ success: false, error: 'Password change failed' });
    }
  }

  // Private helper methods
  private savePasswordHash(email: string, password: string): void {
    // Simplified password storage for localStorage (in production, use proper hashing)
    const passwords = JSON.parse(localStorage.getItem('lost_found_passwords') || '{}');
    passwords[email] = btoa(password); // Base64 encoding (not secure, just for demo)
    localStorage.setItem('lost_found_passwords', JSON.stringify(passwords));
  }

  private verifyPassword(email: string, password: string): boolean {
    const passwords = JSON.parse(localStorage.getItem('lost_found_passwords') || '{}');
    const storedPassword = passwords[email];
    return storedPassword === btoa(password);
  }

  private createToken(user: User): string {
    const tokenData = {
      userId: user.id,
      email: user.email,
      role: user.role,
      createdAt: new Date().toISOString()
    };
    return btoa(JSON.stringify(tokenData));
  }

  private parseToken(token: string): { userId: string; email: string; role: string } | null {
    try {
      const decoded = atob(token);
      return JSON.parse(decoded);
    } catch (error) {
      return null;
    }
  }
}

export default AuthService;