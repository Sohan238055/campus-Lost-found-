import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { User, Item, Claim, SearchFilters, AppState, ItemCategory, ItemStatus } from '../types';
import AuthService from '../services/AuthService';
import DataService from '../services/DataService';

interface RegisterData {
  name: string;
  email: string;
  password: string;
  studentId?: string;
  phone?: string;
  role: 'student' | 'staff' | 'security';
}

interface ItemData {
  title: string;
  description: string;
  category: ItemCategory;
  location: string;
  dateLostFound?: string;
  type: 'lost' | 'found';
  contactInfo?: string;
  reward?: number;
  tags?: string[];
  images?: string[];
}

interface AppContextType {
  state: AppState;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (userData: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  postItem: (itemData: ItemData) => Promise<{ success: boolean; error?: string }>;
  updateItem: (itemId: string, updates: Partial<Item>) => Promise<{ success: boolean; error?: string }>;
  deleteItem: (itemId: string) => void;
  claimItem: (itemId: string, description: string) => Promise<{ success: boolean; error?: string }>;
  updateSearchFilters: (filters: Partial<SearchFilters>) => void;
  getFilteredItems: () => Item[];
  refreshData: () => void;
}

type AppAction = 
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_AUTH'; payload: { user: User | null; isAuthenticated: boolean } }
  | { type: 'SET_ITEMS'; payload: Item[] }
  | { type: 'ADD_ITEM'; payload: Item }
  | { type: 'UPDATE_ITEM'; payload: Item }
  | { type: 'DELETE_ITEM'; payload: string }
  | { type: 'SET_CLAIMS'; payload: Claim[] }
  | { type: 'ADD_CLAIM'; payload: Claim }
  | { type: 'UPDATE_SEARCH_FILTERS'; payload: Partial<SearchFilters> };

const initialState: AppState = {
  auth: {
    user: null,
    isAuthenticated: false,
    isLoading: true
  },
  items: [],
  claims: [],
  searchFilters: {},
  isLoading: false
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    
    case 'SET_AUTH':
      return {
        ...state,
        auth: {
          ...action.payload,
          isLoading: false
        }
      };
    
    case 'SET_ITEMS':
      return { ...state, items: action.payload };
    
    case 'ADD_ITEM':
      return { ...state, items: [...state.items, action.payload] };
    
    case 'UPDATE_ITEM':
      return {
        ...state,
        items: state.items.map(item => 
          item.id === action.payload.id ? action.payload : item
        )
      };
    
    case 'DELETE_ITEM':
      return {
        ...state,
        items: state.items.filter(item => item.id !== action.payload)
      };
    
    case 'SET_CLAIMS':
      return { ...state, claims: action.payload };
    
    case 'ADD_CLAIM':
      return { ...state, claims: [...state.claims, action.payload] };
    
    case 'UPDATE_SEARCH_FILTERS':
      return {
        ...state,
        searchFilters: { ...state.searchFilters, ...action.payload }
      };
    
    default:
      return state;
  }
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const authService = AuthService.getInstance();
  const dataService = DataService.getInstance();

  // Initialize app
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Check authentication
        const user = authService.getCurrentUser();
        dispatch({
          type: 'SET_AUTH',
          payload: { user, isAuthenticated: !!user }
        });

        // Load data
        const items = dataService.getItems();
        const claims = dataService.getClaims();
        
        dispatch({ type: 'SET_ITEMS', payload: items });
        dispatch({ type: 'SET_CLAIMS', payload: claims });
      } catch (error) {
        console.error('App initialization error:', error);
        dispatch({
          type: 'SET_AUTH',
          payload: { user: null, isAuthenticated: false }
        });
      }
    };

    initializeApp();
  }, []);

  const login = async (email: string, password: string) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      const result = await authService.login(email, password);
      
      if (result.success && result.user) {
        dispatch({
          type: 'SET_AUTH',
          payload: { user: result.user, isAuthenticated: true }
        });
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
      return result;
    } catch (error) {
      dispatch({ type: 'SET_LOADING', payload: false });
      return { success: false, error: 'Login failed' };
    }
  };

  const register = async (userData: RegisterData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      const result = await authService.register(userData);
      
      if (result.success && result.user) {
        dispatch({
          type: 'SET_AUTH',
          payload: { user: result.user, isAuthenticated: true }
        });
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
      return result;
    } catch (error) {
      dispatch({ type: 'SET_LOADING', payload: false });
      return { success: false, error: 'Registration failed' };
    }
  };

  const logout = () => {
    authService.logout();
    dispatch({
      type: 'SET_AUTH',
      payload: { user: null, isAuthenticated: false }
    });
  };

  const postItem = async (itemData: ItemData) => {
    if (!state.auth.user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      const newItem: Item = {
        id: dataService.generateId(),
        title: itemData.title,
        description: itemData.description,
        category: itemData.category,
        location: itemData.location,
        dateReported: new Date().toISOString(),
        dateLostFound: itemData.dateLostFound,
        status: 'active' as ItemStatus,
        type: itemData.type,
        userId: state.auth.user.id,
        images: itemData.images || [],
        tags: itemData.tags || [],
        contactInfo: itemData.contactInfo,
        reward: itemData.reward,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      dataService.saveItem(newItem);
      dispatch({ type: 'ADD_ITEM', payload: newItem });

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Failed to post item' };
    }
  };

  const updateItem = async (itemId: string, updates: Partial<Item>) => {
    try {
      const existingItem = dataService.getItemById(itemId);
      if (!existingItem) {
        return { success: false, error: 'Item not found' };
      }

      const updatedItem = { ...existingItem, ...updates, updatedAt: new Date().toISOString() };
      dataService.saveItem(updatedItem);
      dispatch({ type: 'UPDATE_ITEM', payload: updatedItem });

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Failed to update item' };
    }
  };

  const deleteItem = (itemId: string) => {
    dataService.deleteItem(itemId);
    dispatch({ type: 'DELETE_ITEM', payload: itemId });
  };

  const claimItem = async (itemId: string, description: string) => {
    if (!state.auth.user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      const item = dataService.getItemById(itemId);
      if (!item) {
        return { success: false, error: 'Item not found' };
      }

      const newClaim: Claim = {
        id: dataService.generateId(),
        itemId,
        claimantId: state.auth.user.id,
        ownerId: item.userId,
        status: 'pending',
        description,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      dataService.saveClaim(newClaim);
      dispatch({ type: 'ADD_CLAIM', payload: newClaim });

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Failed to claim item' };
    }
  };

  const updateSearchFilters = (filters: Partial<SearchFilters>) => {
    dispatch({ type: 'UPDATE_SEARCH_FILTERS', payload: filters });
  };

  const getFilteredItems = (): Item[] => {
    let filteredItems = [...state.items];

    // Apply search query
    if (state.searchFilters.query) {
      filteredItems = dataService.searchItems(state.searchFilters.query, filteredItems);
    }

    // Apply category filter
    if (state.searchFilters.category) {
      filteredItems = filteredItems.filter(item => item.category === state.searchFilters.category);
    }

    // Apply location filter
    if (state.searchFilters.location) {
      filteredItems = filteredItems.filter(item => 
        item.location.toLowerCase().includes(state.searchFilters.location!.toLowerCase())
      );
    }

    // Apply type filter
    if (state.searchFilters.type) {
      filteredItems = filteredItems.filter(item => item.type === state.searchFilters.type);
    }

    // Apply status filter
    if (state.searchFilters.status) {
      filteredItems = filteredItems.filter(item => item.status === state.searchFilters.status);
    }

    // Apply date filters
    if (state.searchFilters.dateFrom) {
      filteredItems = filteredItems.filter(item => 
        new Date(item.dateReported) >= new Date(state.searchFilters.dateFrom!)
      );
    }

    if (state.searchFilters.dateTo) {
      filteredItems = filteredItems.filter(item => 
        new Date(item.dateReported) <= new Date(state.searchFilters.dateTo!)
      );
    }

    // Sort by most recent
    return filteredItems.sort((a, b) => 
      new Date(b.dateReported).getTime() - new Date(a.dateReported).getTime()
    );
  };

  const refreshData = () => {
    const items = dataService.getItems();
    const claims = dataService.getClaims();
    
    dispatch({ type: 'SET_ITEMS', payload: items });
    dispatch({ type: 'SET_CLAIMS', payload: claims });
  };

  return (
    <AppContext.Provider value={{
      state,
      login,
      register,
      logout,
      postItem,
      updateItem,
      deleteItem,
      claimItem,
      updateSearchFilters,
      getFilteredItems,
      refreshData
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}