import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, User, Eye } from 'lucide-react';
import { Item } from '../types';

interface ItemCardProps {
  item: Item;
  onViewDetails: (item: Item) => void;
  onClaim?: (item: Item) => void;
  showClaimButton?: boolean;
  currentUserId?: string;
}

const categoryColors = {
  electronics: 'bg-blue-100 text-blue-800',
  clothing: 'bg-purple-100 text-purple-800',
  accessories: 'bg-pink-100 text-pink-800',
  books: 'bg-green-100 text-green-800',
  keys: 'bg-yellow-100 text-yellow-800',
  bags: 'bg-indigo-100 text-indigo-800',
  documents: 'bg-red-100 text-red-800',
  sports: 'bg-orange-100 text-orange-800',
  other: 'bg-gray-100 text-gray-800'
};

const statusColors = {
  active: 'bg-green-100 text-green-800',
  claimed: 'bg-yellow-100 text-yellow-800',
  returned: 'bg-blue-100 text-blue-800',
  expired: 'bg-gray-100 text-gray-800'
};

export default function ItemCard({ 
  item, 
  onViewDetails, 
  onClaim, 
  showClaimButton = true,
  currentUserId 
}: ItemCardProps) {
  const isOwnItem = currentUserId === item.userId;
  const canClaim = showClaimButton && !isOwnItem && item.status === 'active' && onClaim;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <Card className="h-full hover:shadow-lg transition-shadow duration-200">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="text-lg font-semibold line-clamp-2 flex-1">
            {item.title}
          </CardTitle>
          <Badge 
            variant="secondary" 
            className={`${item.type === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'} shrink-0`}
          >
            {item.type}
          </Badge>
        </div>
        
        <div className="flex flex-wrap gap-2 mt-2">
          <Badge 
            variant="outline" 
            className={categoryColors[item.category]}
          >
            {item.category}
          </Badge>
          <Badge 
            variant="outline" 
            className={statusColors[item.status]}
          >
            {item.status}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {/* Image */}
        {item.images && item.images.length > 0 && (
          <div className="mb-4 rounded-lg overflow-hidden bg-gray-100">
            <img 
              src={item.images[0]} 
              alt={item.title}
              className="w-full h-48 object-cover"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
              }}
            />
          </div>
        )}

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
          {item.description}
        </p>

        {/* Location and Date */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{item.location}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>Reported {formatDate(item.dateReported)}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onViewDetails(item)}
            className="flex-1"
          >
            <Eye className="h-4 w-4 mr-2" />
            View Details
          </Button>
          
          {canClaim && (
            <Button 
              size="sm" 
              onClick={() => onClaim(item)}
              className="flex-1"
            >
              Claim Item
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}