import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Star, Award, Crown } from 'lucide-react';

interface GoodSamaritanBadgeProps {
  returnCount: number;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export default function GoodSamaritanBadge({ 
  returnCount, 
  size = 'md', 
  showText = true 
}: GoodSamaritanBadgeProps) {
  const getBadgeInfo = (count: number) => {
    if (count >= 10) {
      return {
        level: 'Gold',
        icon: Crown,
        className: 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white',
        description: 'Campus Hero'
      };
    } else if (count >= 5) {
      return {
        level: 'Silver',
        icon: Award,
        className: 'bg-gradient-to-r from-gray-400 to-gray-600 text-white',
        description: 'Community Helper'
      };
    } else if (count >= 1) {
      return {
        level: 'Bronze',
        icon: Star,
        className: 'bg-gradient-to-r from-orange-400 to-orange-600 text-white',
        description: 'Good Samaritan'
      };
    }
    return null;
  };

  const badgeInfo = getBadgeInfo(returnCount);

  if (!badgeInfo) {
    return null;
  }

  const { level, icon: Icon, className, description } = badgeInfo;

  const sizeClasses = {
    sm: 'text-xs px-2 py-1',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-2'
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-4 w-4',
    lg: 'h-5 w-5'
  };

  return (
    <div className="flex items-center gap-2">
      <Badge 
        className={`
          ${className} 
          ${sizeClasses[size]} 
          flex items-center gap-1 
          shadow-lg 
          animate-pulse-slow
          border-0
        `}
      >
        <Icon className={iconSizes[size]} />
        {showText && (
          <span className="font-semibold">
            {level} Helper
          </span>
        )}
      </Badge>
      
      {showText && size !== 'sm' && (
        <div className="text-xs text-gray-500">
          {returnCount} item{returnCount !== 1 ? 's' : ''} returned
        </div>
      )}
    </div>
  );
}

export { GoodSamaritanBadge };