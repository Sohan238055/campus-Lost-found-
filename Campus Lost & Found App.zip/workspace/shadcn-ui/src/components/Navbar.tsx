import React from 'react';
import { Button } from '@/components/ui/button';
import { Package, Plus, Search, Home } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-white/90 backdrop-blur-md shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center cursor-pointer" onClick={() => navigate('/')}>
            <Package className="h-8 w-8 text-blue-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">
              Campus Lost & Found
            </span>
          </div>

          {/* Navigation */}
          <div className="flex items-center space-x-4">
            <Button
              variant={isActive('/') ? 'default' : 'ghost'}
              onClick={() => navigate('/')}
              className="flex items-center gap-2"
            >
              <Home className="h-4 w-4" />
              <span className="hidden sm:inline">Home</span>
            </Button>
            
            {/* Enhanced Report Item Button */}
            <div className="relative">
              <Button
                variant={isActive('/report') ? 'default' : 'outline'}
                onClick={() => navigate('/report')}
                className={`
                  flex items-center gap-2 relative overflow-hidden
                  ${isActive('/report') 
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white border-0 shadow-lg' 
                    : 'bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 hover:from-green-600 hover:to-emerald-600 shadow-md hover:shadow-lg'
                  }
                  transition-all duration-300 transform hover:scale-105 animate-pulse-slow
                `}
              >
                <Plus className="h-4 w-4 animate-spin" />
                <span className="hidden sm:inline font-semibold">Report Item</span>
                <span className="sm:hidden font-semibold">Report</span>
                
                {/* Animated shine effect */}
                <div className="absolute inset-0 -top-1 -bottom-1 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 translate-x-[-100%] animate-shine"></div>
              </Button>
              
              {/* Pulsing ring effect */}
              <div className="absolute inset-0 rounded-md bg-gradient-to-r from-green-500 to-emerald-500 opacity-30 animate-ping"></div>
            </div>

            {/* Enhanced Browse Items Button */}
            <div className="relative">
              <Button
                variant={isActive('/items') ? 'default' : 'outline'}
                onClick={() => navigate('/items')}
                className={`
                  flex items-center gap-2 relative overflow-hidden
                  ${isActive('/items') 
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0 shadow-lg' 
                    : 'bg-gradient-to-r from-blue-500 to-purple-500 text-white border-0 hover:from-blue-600 hover:to-purple-600 shadow-md hover:shadow-lg'
                  }
                  transition-all duration-300 transform hover:scale-105 animate-pulse-slow
                `}
              >
                <Search className="h-4 w-4 animate-bounce" />
                <span className="hidden sm:inline font-semibold">Browse Items</span>
                <span className="sm:hidden font-semibold">Browse</span>
                
                {/* Animated shine effect */}
                <div className="absolute inset-0 -top-1 -bottom-1 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 translate-x-[-100%] animate-shine"></div>
              </Button>
              
              {/* Pulsing ring effect */}
              <div className="absolute inset-0 rounded-md bg-gradient-to-r from-blue-500 to-purple-500 opacity-30 animate-ping"></div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}