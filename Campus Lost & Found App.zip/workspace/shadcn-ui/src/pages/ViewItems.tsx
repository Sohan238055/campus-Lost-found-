import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, Package, Calendar, MapPin, X, Award } from 'lucide-react';
import GoodSamaritanBadge from '../components/GoodSamaritanBadge';

interface Item {
  id: string;
  title: string;
  description: string;
  location: string;
  type: 'lost' | 'found';
  dateReported: string;
  images?: string[];
  status?: string;
  claimedAt?: string;
  returnedAt?: string;
}

interface Claim {
  id: string;
  itemId: string;
  status: string;
  createdAt: string;
}

export default function ViewItems() {
  const [items, setItems] = useState<Item[]>([]);
  const [filteredItems, setFilteredItems] = useState<Item[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'lost' | 'found'>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [goodSamaritanStats, setGoodSamaritanStats] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    // Load items from localStorage
    const savedItems = JSON.parse(localStorage.getItem('campus_lost_found_items') || '[]');
    const savedClaims = JSON.parse(localStorage.getItem('campus_lost_found_claims') || '[]');
    
    setItems(savedItems);
    setFilteredItems(savedItems);

    // Calculate Good Samaritan stats (simplified - count found items that led to successful returns)
    const stats: { [key: string]: number } = {};
    savedItems.forEach((item: Item) => {
      if (item.type === 'found' && (item.status === 'claimed' || item.status === 'returned')) {
        const userId = item.userId || 'anonymous';
        stats[userId] = (stats[userId] || 0) + 1;
      }
    });
    setGoodSamaritanStats(stats);
  }, []);

  useEffect(() => {
    // Filter items based on search query and type filter
    let filtered = items;

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.location.toLowerCase().includes(query)
      );
    }

    // Apply type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter(item => item.type === typeFilter);
    }

    // Sort by most recent
    filtered = filtered.sort((a, b) => 
      new Date(b.dateReported).getTime() - new Date(a.dateReported).getTime()
    );

    setFilteredItems(filtered);
  }, [items, searchQuery, typeFilter]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const clearFilters = () => {
    setSearchQuery('');
    setTypeFilter('all');
  };

  const hasActiveFilters = searchQuery.trim() || typeFilter !== 'all';

  const getItemStatusBadge = (item: Item) => {
    if (item.status === 'claimed') {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Claimed</Badge>;
    }
    if (item.status === 'returned') {
      return <Badge variant="outline" className="bg-green-100 text-green-800">Returned</Badge>;
    }
    return null;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Browse Items</h1>
        <p className="text-gray-600 mt-2">
          Search through reported lost and found items
        </p>
      </div>

      {/* Good Samaritan Highlight */}
      {Object.keys(goodSamaritanStats).length > 0 && (
        <Card className="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-blue-600" />
              Community Heroes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Celebrating our Good Samaritans who help reunite items with their owners!
            </p>
            <div className="flex flex-wrap gap-3">
              {Object.entries(goodSamaritanStats).map(([userId, count]) => (
                <div key={userId} className="flex items-center gap-2">
                  <span className="text-sm font-medium">Community Member</span>
                  <GoodSamaritanBadge count={count} size="sm" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search and Filters */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Search & Filter
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by title, description, or location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filter Toggle */}
            <div className="flex justify-between items-center">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4 mr-2" />
                {showFilters ? 'Hide Filters' : 'Show Filters'}
              </Button>
              
              <div className="flex items-center gap-4">
                {hasActiveFilters && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearFilters}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear Filters
                  </Button>
                )}
                <span className="text-sm text-gray-600">
                  {filteredItems.length} item{filteredItems.length !== 1 ? 's' : ''} found
                </span>
              </div>
            </div>

            {/* Filters */}
            {showFilters && (
              <div className="pt-4 border-t">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Item Type
                    </label>
                    <div className="flex gap-2">
                      <Button
                        variant={typeFilter === 'all' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setTypeFilter('all')}
                      >
                        All
                      </Button>
                      <Button
                        variant={typeFilter === 'lost' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setTypeFilter('lost')}
                      >
                        Lost
                      </Button>
                      <Button
                        variant={typeFilter === 'found' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setTypeFilter('found')}
                      >
                        Found
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Items Grid */}
      <div className="space-y-6">
        {filteredItems.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {hasActiveFilters ? 'No items match your search' : 'No items reported yet'}
              </h3>
              <p className="text-gray-600 mb-6">
                {hasActiveFilters 
                  ? 'Try adjusting your search criteria or filters.'
                  : 'Be the first to help your campus community by reporting an item!'
                }
              </p>
              {hasActiveFilters ? (
                <Button onClick={clearFilters} variant="outline">
                  Clear Filters
                </Button>
              ) : (
                <Button onClick={() => window.location.href = '/report'}>
                  Report an Item
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <Card key={item.id} className="hover:shadow-lg transition-shadow duration-200">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start gap-2">
                    <CardTitle className="text-lg font-semibold line-clamp-2 flex-1">
                      {item.title}
                    </CardTitle>
                    <div className="flex flex-col gap-1 shrink-0">
                      <Badge 
                        variant="secondary" 
                        className={`${item.type === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}
                      >
                        {item.type}
                      </Badge>
                      {getItemStatusBadge(item)}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pt-0">
                  {/* Image */}
                  {item.images && item.images.length > 0 && (
                    <div className="mb-4 rounded-lg overflow-hidden bg-gray-100">
                      <img 
                        src={item.images[0]} 
                        alt={item.title}
                        className="w-full h-48 object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                    </div>
                  )}

                  {/* Description */}
                  <p className="text-sm text-gray-600 mb-4 line-clamp-3">
                    {item.description}
                  </p>

                  {/* Location and Date */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <MapPin className="h-4 w-4 flex-shrink-0" />
                      <span className="line-clamp-1">{item.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Calendar className="h-4 w-4 flex-shrink-0" />
                      <span>Reported {formatDate(item.dateReported)}</span>
                    </div>
                  </div>

                  {/* Good Samaritan Badge for Found Items */}
                  {item.type === 'found' && item.status === 'returned' && (
                    <div className="mt-3 pt-3 border-t">
                      <div className="flex items-center justify-center">
                        <GoodSamaritanBadge count={1} size="sm" showCount={false} />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}