import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, Plus, TrendingUp, Package, Users, CheckCircle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import ItemCard from '../components/ItemCard';
import { Item, ItemCategory, ItemStatus, SearchFilters } from '../types';

export default function Dashboard() {
  const { state, updateSearchFilters, getFilteredItems } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ItemCategory | 'all'>('all');
  const [selectedType, setSelectedType] = useState<'lost' | 'found' | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<ItemStatus | 'all'>('all');
  const [showFilters, setShowFilters] = useState(false);

  const filteredItems = getFilteredItems();

  // Update search filters when inputs change
  useEffect(() => {
    const filters: SearchFilters = {};
    
    if (searchQuery.trim()) {
      filters.query = searchQuery.trim();
    }
    
    if (selectedCategory !== 'all') {
      filters.category = selectedCategory as ItemCategory;
    }
    
    if (selectedType !== 'all') {
      filters.type = selectedType as 'lost' | 'found';
    }
    
    if (selectedStatus !== 'all') {
      filters.status = selectedStatus as ItemStatus;
    }

    updateSearchFilters(filters);
  }, [searchQuery, selectedCategory, selectedType, selectedStatus, updateSearchFilters]);

  const handleViewDetails = (item: Item) => {
    // TODO: Navigate to item details page
    console.log('View details for item:', item.id);
  };

  const handleClaimItem = (item: Item) => {
    // TODO: Open claim modal
    console.log('Claim item:', item.id);
  };

  // Calculate statistics
  const stats = {
    totalItems: state.items.length,
    activeItems: state.items.filter(item => item.status === 'active').length,
    returnedItems: state.items.filter(item => item.status === 'returned').length,
    totalUsers: new Set(state.items.map(item => item.userId)).size
  };

  const categories: { value: ItemCategory | 'all'; label: string }[] = [
    { value: 'all', label: 'All Categories' },
    { value: 'electronics', label: 'Electronics' },
    { value: 'clothing', label: 'Clothing' },
    { value: 'accessories', label: 'Accessories' },
    { value: 'books', label: 'Books' },
    { value: 'keys', label: 'Keys' },
    { value: 'bags', label: 'Bags' },
    { value: 'documents', label: 'Documents' },
    { value: 'sports', label: 'Sports Equipment' },
    { value: 'other', label: 'Other' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Campus Lost & Found</h1>
              <p className="text-gray-600 mt-1">Help reunite lost items with their owners</p>
            </div>
            <div className="flex gap-3">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Report Lost Item
              </Button>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Report Found Item
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Package className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Items</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalItems}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Items</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.activeItems}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <CheckCircle className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Returned Items</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.returnedItems}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Users</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalUsers}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Items
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search by title, description, or location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Filter Toggle */}
              <div className="flex justify-between items-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="h-4 w-4 mr-2" />
                  {showFilters ? 'Hide Filters' : 'Show Filters'}
                </Button>
                
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span>{filteredItems.length} items found</span>
                </div>
              </div>

              {/* Filters */}
              {showFilters && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Type
                    </label>
                    <Select value={selectedType} onValueChange={setSelectedType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="lost">Lost Items</SelectItem>
                        <SelectItem value="found">Found Items</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status
                    </label>
                    <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="claimed">Claimed</SelectItem>
                        <SelectItem value="returned">Returned</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Items Grid */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">
              {searchQuery || selectedCategory !== 'all' || selectedType !== 'all' || selectedStatus !== 'all' 
                ? 'Search Results' 
                : 'Recent Items'}
            </h2>
          </div>

          {filteredItems.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No items found</h3>
                <p className="text-gray-600 mb-4">
                  {searchQuery || selectedCategory !== 'all' || selectedType !== 'all' || selectedStatus !== 'all'
                    ? 'Try adjusting your search criteria or filters.'
                    : 'No items have been reported yet. Be the first to help your campus community!'}
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Report an Item
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredItems.map((item) => (
                <ItemCard
                  key={item.id}
                  item={item}
                  onViewDetails={handleViewDetails}
                  onClaim={handleClaimItem}
                  currentUserId={state.auth.user?.id}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}