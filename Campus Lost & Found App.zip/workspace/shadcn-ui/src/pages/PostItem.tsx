import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Upload, X, Camera, MapPin, Calendar, Tag } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { ItemCategory } from '../types';
import DataService from '../services/DataService';

interface PostItemForm {
  title: string;
  description: string;
  category: ItemCategory | '';
  location: string;
  dateLostFound: string;
  type: 'lost' | 'found';
  contactInfo: string;
  reward: string;
  tags: string[];
  images: string[];
}

export default function PostItem() {
  const { postItem, state } = useApp();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentTag, setCurrentTag] = useState('');
  const [form, setForm] = useState<PostItemForm>({
    title: '',
    description: '',
    category: '',
    location: '',
    dateLostFound: '',
    type: 'lost',
    contactInfo: '',
    reward: '',
    tags: [],
    images: []
  });

  const dataService = DataService.getInstance();

  const categories: { value: ItemCategory; label: string }[] = [
    { value: 'electronics', label: 'Electronics' },
    { value: 'clothing', label: 'Clothing' },
    { value: 'accessories', label: 'Accessories' },
    { value: 'books', label: 'Books' },
    { value: 'keys', label: 'Keys' },
    { value: 'bags', label: 'Bags' },
    { value: 'documents', label: 'Documents' },
    { value: 'sports', label: 'Sports Equipment' },
    { value: 'other', label: 'Other' }
  ];

  const handleInputChange = (field: keyof PostItemForm, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const newImages: string[] = [];
    
    for (let i = 0; i < Math.min(files.length, 5 - form.images.length); i++) {
      const file = files[i];
      
      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert('Please select only image files.');
        continue;
      }

      // Validate file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size should be less than 5MB.');
        continue;
      }

      try {
        const base64Image = await dataService.saveImage(file);
        newImages.push(base64Image);
      } catch (error) {
        console.error('Error processing image:', error);
        alert('Error processing image. Please try again.');
      }
    }

    setForm(prev => ({
      ...prev,
      images: [...prev.images, ...newImages]
    }));
  };

  const removeImage = (index: number) => {
    setForm(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const addTag = () => {
    if (currentTag.trim() && !form.tags.includes(currentTag.trim()) && form.tags.length < 10) {
      setForm(prev => ({
        ...prev,
        tags: [...prev.tags, currentTag.trim()]
      }));
      setCurrentTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setForm(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!form.title.trim()) {
      alert('Please enter a title.');
      return;
    }
    
    if (!form.description.trim()) {
      alert('Please enter a description.');
      return;
    }
    
    if (!form.category) {
      alert('Please select a category.');
      return;
    }
    
    if (!form.location.trim()) {
      alert('Please enter a location.');
      return;
    }

    setIsSubmitting(true);

    try {
      const itemData = {
        title: form.title.trim(),
        description: form.description.trim(),
        category: form.category,
        location: form.location.trim(),
        dateLostFound: form.dateLostFound || undefined,
        type: form.type,
        contactInfo: form.contactInfo.trim() || undefined,
        reward: form.reward ? parseFloat(form.reward) : undefined,
        tags: form.tags,
        images: form.images
      };

      const result = await postItem(itemData);
      
      if (result.success) {
        alert('Item posted successfully!');
        // Reset form
        setForm({
          title: '',
          description: '',
          category: '',
          location: '',
          dateLostFound: '',
          type: 'lost',
          contactInfo: '',
          reward: '',
          tags: [],
          images: []
        });
      } else {
        alert(result.error || 'Failed to post item. Please try again.');
      }
    } catch (error) {
      console.error('Error posting item:', error);
      alert('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Report an Item</h1>
          <p className="text-gray-600 mt-2">
            Help your campus community by reporting lost or found items
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tag className="h-5 w-5" />
              Item Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Item Type */}
              <div>
                <Label className="text-base font-medium">Item Type *</Label>
                <div className="flex gap-4 mt-2">
                  <Button
                    type="button"
                    variant={form.type === 'lost' ? 'default' : 'outline'}
                    onClick={() => handleInputChange('type', 'lost')}
                    className="flex-1"
                  >
                    Lost Item
                  </Button>
                  <Button
                    type="button"
                    variant={form.type === 'found' ? 'default' : 'outline'}
                    onClick={() => handleInputChange('type', 'found')}
                    className="flex-1"
                  >
                    Found Item
                  </Button>
                </div>
              </div>

              {/* Title */}
              <div>
                <Label htmlFor="title" className="text-base font-medium">
                  Title *
                </Label>
                <Input
                  id="title"
                  placeholder="e.g., Black iPhone 13 Pro"
                  value={form.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  className="mt-2"
                />
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description" className="text-base font-medium">
                  Description *
                </Label>
                <Textarea
                  id="description"
                  placeholder="Provide detailed description including color, brand, size, distinctive features..."
                  value={form.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  className="mt-2 min-h-[100px]"
                />
              </div>

              {/* Category */}
              <div>
                <Label className="text-base font-medium">Category *</Label>
                <Select value={form.category} onValueChange={(value) => handleInputChange('category', value)}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Location */}
              <div>
                <Label htmlFor="location" className="text-base font-medium">
                  Location *
                </Label>
                <div className="relative mt-2">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    id="location"
                    placeholder="e.g., Library 2nd floor, Student Center cafeteria"
                    value={form.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Date Lost/Found */}
              <div>
                <Label htmlFor="dateLostFound" className="text-base font-medium">
                  Date {form.type === 'lost' ? 'Lost' : 'Found'}
                </Label>
                <div className="relative mt-2">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    id="dateLostFound"
                    type="date"
                    value={form.dateLostFound}
                    onChange={(e) => handleInputChange('dateLostFound', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Images */}
              <div>
                <Label className="text-base font-medium">Photos</Label>
                <p className="text-sm text-gray-600 mt-1">
                  Add up to 5 photos to help identify the item (Max 5MB each)
                </p>
                
                <div className="mt-3">
                  {form.images.length < 5 && (
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                      <input
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="image-upload"
                      />
                      <label htmlFor="image-upload" className="cursor-pointer">
                        <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">
                          Click to upload or drag and drop images
                        </p>
                      </label>
                    </div>
                  )}

                  {form.images.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4">
                      {form.images.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`Upload ${index + 1}`}
                            className="w-full h-24 object-cover rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Tags */}
              <div>
                <Label className="text-base font-medium">Tags</Label>
                <p className="text-sm text-gray-600 mt-1">
                  Add keywords to help others find this item
                </p>
                
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="Add a tag..."
                    value={currentTag}
                    onChange={(e) => setCurrentTag(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addTag();
                      }
                    }}
                  />
                  <Button type="button" onClick={addTag} variant="outline">
                    Add
                  </Button>
                </div>

                {form.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {form.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center gap-1">
                        {tag}
                        <button
                          type="button"
                          onClick={() => removeTag(tag)}
                          className="ml-1 hover:text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Contact Info */}
              <div>
                <Label htmlFor="contactInfo" className="text-base font-medium">
                  Contact Information
                </Label>
                <p className="text-sm text-gray-600 mt-1">
                  Optional: Additional contact details (phone, email, etc.)
                </p>
                <Input
                  id="contactInfo"
                  placeholder="e.g., john.doe@university.edu or (555) 123-4567"
                  value={form.contactInfo}
                  onChange={(e) => handleInputChange('contactInfo', e.target.value)}
                  className="mt-2"
                />
              </div>

              {/* Reward */}
              {form.type === 'lost' && (
                <div>
                  <Label htmlFor="reward" className="text-base font-medium">
                    Reward (Optional)
                  </Label>
                  <p className="text-sm text-gray-600 mt-1">
                    Offer a reward for returning your item
                  </p>
                  <div className="relative mt-2">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
                    <Input
                      id="reward"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={form.reward}
                      onChange={(e) => handleInputChange('reward', e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <div className="pt-6 border-t">
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Posting...' : `Post ${form.type === 'lost' ? 'Lost' : 'Found'} Item`}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}