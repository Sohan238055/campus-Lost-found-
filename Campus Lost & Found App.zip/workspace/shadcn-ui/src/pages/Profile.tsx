import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User, Package, MessageSquare, Edit, Trash2, Eye } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { Item } from '../types';

export default function Profile() {
  const { state, updateItem, deleteItem } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: state.auth.user?.name || '',
    email: state.auth.user?.email || '',
    phone: state.auth.user?.phone || '',
    studentId: state.auth.user?.studentId || ''
  });

  const userItems = state.items.filter(item => item.userId === state.auth.user?.id);
  const userClaims = state.claims.filter(claim => 
    claim.claimantId === state.auth.user?.id || claim.ownerId === state.auth.user?.id
  );

  const handleProfileUpdate = async () => {
    // TODO: Implement profile update
    setIsEditing(false);
  };

  const handleItemStatusUpdate = async (itemId: string, status: 'active' | 'claimed' | 'returned' | 'expired') => {
    await updateItem(itemId, { status });
  };

  const handleDeleteItem = (itemId: string) => {
    if (confirm('Are you sure you want to delete this item?')) {
      deleteItem(itemId);
    }
  };

  const handleViewDetails = (item: Item) => {
    // TODO: Navigate to item details
    console.log('View details:', item.id);
  };

  const getStatusColor = (status: string) => {
    const colors = {
      active: 'bg-green-100 text-green-800',
      claimed: 'bg-yellow-100 text-yellow-800',
      returned: 'bg-blue-100 text-blue-800',
      expired: 'bg-gray-100 text-gray-800',
      pending: 'bg-orange-100 text-orange-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      completed: 'bg-blue-100 text-blue-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (!state.auth.user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Not Logged In</h3>
            <p className="text-gray-600">Please log in to view your profile.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
          <p className="text-gray-600 mt-2">Manage your account and track your items</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Profile Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isEditing ? (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        value={editForm.name}
                        onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={editForm.email}
                        onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={editForm.phone}
                        onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="studentId">Student ID</Label>
                      <Input
                        id="studentId"
                        value={editForm.studentId}
                        onChange={(e) => setEditForm(prev => ({ ...prev, studentId: e.target.value }))}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={handleProfileUpdate} size="sm">
                        Save
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(false)} size="sm">
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Name</Label>
                      <p className="text-gray-900">{state.auth.user.name}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Email</Label>
                      <p className="text-gray-900">{state.auth.user.email}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Phone</Label>
                      <p className="text-gray-900">{state.auth.user.phone || 'Not provided'}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Student ID</Label>
                      <p className="text-gray-900">{state.auth.user.studentId || 'Not provided'}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Role</Label>
                      <Badge variant="outline" className="capitalize">
                        {state.auth.user.role}
                      </Badge>
                    </div>
                    <Button onClick={() => setIsEditing(true)} size="sm" variant="outline">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Items Posted</span>
                    <span className="font-medium">{userItems.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Active Items</span>
                    <span className="font-medium">
                      {userItems.filter(item => item.status === 'active').length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Returned Items</span>
                    <span className="font-medium">
                      {userItems.filter(item => item.status === 'returned').length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Claims Made</span>
                    <span className="font-medium">
                      {userClaims.filter(claim => claim.claimantId === state.auth.user?.id).length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="items" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="items" className="flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  My Items
                </TabsTrigger>
                <TabsTrigger value="claims" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  My Claims
                </TabsTrigger>
              </TabsList>

              <TabsContent value="items" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>My Posted Items</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {userItems.length === 0 ? (
                      <div className="text-center py-8">
                        <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No Items Posted</h3>
                        <p className="text-gray-600 mb-4">
                          You haven't posted any items yet. Start helping your campus community!
                        </p>
                        <Button>Post an Item</Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {userItems.map((item) => (
                          <div key={item.id} className="border rounded-lg p-4">
                            <div className="flex justify-between items-start mb-4">
                              <div className="flex-1">
                                <h3 className="font-semibold text-lg">{item.title}</h3>
                                <p className="text-gray-600 text-sm mt-1">{item.description}</p>
                                <div className="flex gap-2 mt-2">
                                  <Badge variant="outline" className={`${item.type === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                    {item.type}
                                  </Badge>
                                  <Badge variant="outline" className={getStatusColor(item.status)}>
                                    {item.status}
                                  </Badge>
                                </div>
                              </div>
                              {item.images && item.images.length > 0 && (
                                <img 
                                  src={item.images[0]} 
                                  alt={item.title}
                                  className="w-16 h-16 object-cover rounded-lg ml-4"
                                />
                              )}
                            </div>

                            <div className="flex justify-between items-center">
                              <div className="text-sm text-gray-500">
                                Posted {new Date(item.dateReported).toLocaleDateString()}
                              </div>
                              <div className="flex gap-2">
                                <Button size="sm" variant="outline" onClick={() => handleViewDetails(item)}>
                                  <Eye className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                                
                                {item.status === 'active' && (
                                  <Select 
                                    value={item.status} 
                                    onValueChange={(value: string) => handleItemStatusUpdate(item.id, value as 'active' | 'claimed' | 'returned' | 'expired')}
                                  >
                                    <SelectTrigger className="w-32">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="active">Active</SelectItem>
                                      <SelectItem value="claimed">Claimed</SelectItem>
                                      <SelectItem value="returned">Returned</SelectItem>
                                    </SelectContent>
                                  </Select>
                                )}

                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleDeleteItem(item.id)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="claims" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>My Claims</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {userClaims.length === 0 ? (
                      <div className="text-center py-8">
                        <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No Claims</h3>
                        <p className="text-gray-600">
                          You haven't made any claims yet.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {userClaims.map((claim) => {
                          const item = state.items.find(i => i.id === claim.itemId);
                          const isMyItem = claim.ownerId === state.auth.user?.id;
                          
                          return (
                            <div key={claim.id} className="border rounded-lg p-4">
                              <div className="flex justify-between items-start">
                                <div className="flex-1">
                                  <h3 className="font-semibold">{item?.title || 'Unknown Item'}</h3>
                                  <p className="text-gray-600 text-sm mt-1">{claim.description}</p>
                                  <div className="flex gap-2 mt-2">
                                    <Badge variant="outline" className={getStatusColor(claim.status)}>
                                      {claim.status}
                                    </Badge>
                                    <Badge variant="outline">
                                      {isMyItem ? 'Claim on my item' : 'My claim'}
                                    </Badge>
                                  </div>
                                </div>
                                <div className="text-sm text-gray-500">
                                  {new Date(claim.createdAt).toLocaleDateString()}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}