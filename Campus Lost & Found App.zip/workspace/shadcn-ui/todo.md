# Campus Lost and Found App - Implementation Todo

## MVP Implementation Plan

### Core Files to Create (8 files max):

1. **src/types/index.ts** - All TypeScript interfaces and types
2. **src/services/DataService.ts** - localStorage data management service
3. **src/services/AuthService.ts** - User authentication service
4. **src/contexts/AppContext.tsx** - Global state management
5. **src/components/ItemCard.tsx** - Reusable item display component
6. **src/pages/Dashboard.tsx** - Main dashboard with search/filter
7. **src/pages/PostItem.tsx** - Form to post lost/found items
8. **src/pages/Profile.tsx** - User profile and item management

### Key Features to Implement:
- User registration/login with localStorage
- Post lost/found items with image upload
- Search and filter items by category, location, keywords
- Claim/return item functionality
- User dashboard to manage posted items
- Responsive design

### Implementation Order:
1. Setup types and data models
2. Create localStorage data service
3. Implement authentication service
4. Setup global state context
5. Create main dashboard with search
6. Build item posting form
7. Add user profile management
8. Style with responsive design