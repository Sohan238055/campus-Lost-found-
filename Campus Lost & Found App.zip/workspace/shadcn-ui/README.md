# Shadcn-UI Template Usage Instructions

## technology stack

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

All shadcn/ui components have been downloaded under `@/components/ui`.

## File Structure

- `index.html` - HTML entry point
- `vite.config.ts` - Vite configuration file
- `tailwind.config.js` - Tailwind CSS configuration file
- `package.json` - NPM dependencies and scripts
- `src/app.tsx` - Root component of the project
- `src/main.tsx` - Project entry point
- `src/index.css` - Existing CSS configuration
- `src/pages/Index.tsx` - Home page logic

## Components

- All shadcn/ui components are pre-downloaded and available at `@/components/ui`

## Styling

- Add global styles to `src/index.css` or create new CSS files as needed
- Use Tailwind classes for styling components

## Development

- Import components from `@/components/ui` in your React components
- Customize the UI by modifying the Tailwind configuration

## Note

- The `@/` path alias points to the `src/` directory
- In your typescript code, don't re-export types that you're already importing

# Commands

**Install Dependencies**

```shell
pnpm i
```

**Add Dependencies**

```shell
pnpm add some_new_dependency

**Start Preview**

```shell
pnpm run dev
```

**To build**

```shell
pnpm run build
```
LOst and Found Portal:
🎯 Goal:

To help students and staff easily report and recover lost or found items on campus using a simple, responsive web app — no backend required.

🛠️ Technology Stack:

Frontend: HTML, CSS, JavaScript (or MGX)

Storage: localStorage (browser-based)

Optional (future): Supabase or Firebase for persistent backend

📲 Core Features:

Report Item Form

Type: Lost / Found

Title & Description

Emoji-based Category (📱 🎒 📚 👓)

Location Dropdown (e.g., Library, Cafeteria, Lab)

Image Upload

Custom Verification Question (for Lost items)

Item Listing Page

Show items in card view

Filter by type (Lost/Found), category, location

Display image, emoji category, and location badge

Auto-Match System

When a lost item is reported, automatically show similar found items (based on keywords in title/category)

Claim & Verification Flow

User clicks "Claim" on a matching item

Prompted to answer the verification question (e.g., "What color is it?")

Match success: mark item as returned

Good Samaritan Badge

If someone returns an item, they get a visual badge on their name/post

Optional: keep count of returns per user

💡 Why This Solution Works:

Fast to Build: Can be built in 30–60 minutes using MGX or plain HTML/JS.

No Backend Needed: Uses localStorage for data, perfect for prototyping.

User-Friendly: Emoji categories, dropdowns, and matching suggestions make it intuitive.

Unique Touch: Claim verification and badges add credibility and motivation.