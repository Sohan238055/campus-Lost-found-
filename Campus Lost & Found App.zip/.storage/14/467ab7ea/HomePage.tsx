import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Search, Plus, TrendingUp, Users, MapPin, Calendar } from 'lucide-react';

interface Item {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  type: 'lost' | 'found';
  dateReported: string;
  images: string[];
}

interface Stats {
  totalItems: number;
  lostItems: number;
  foundItems: number;
  reunited: number;
}

export default function HomePage() {
  const [stats, setStats] = useState<Stats>({
    totalItems: 0,
    lostItems: 0,
    foundItems: 0,
    reunited: 0
  });
  const [recentItems, setRecentItems] = useState<Item[]>([]);

  useEffect(() => {
    // Load stats from localStorage
    const savedStats = localStorage.getItem('campus_lost_found_stats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }

    // Load recent items
    const savedItems = localStorage.getItem('campus_lost_found_items');
    if (savedItems) {
      const items = JSON.parse(savedItems);
      setRecentItems(items.slice(0, 3)); // Show 3 most recent items
    }
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="animate-float mb-8">
              <Package className="h-20 w-20 text-blue-600 mx-auto mb-6" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Campus Lost & Found
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Connecting students with their lost belongings through our smart matching system. 
              Report lost items, help others find their belongings, and build a stronger campus community.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/report">
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3">
                  <Plus className="h-5 w-5 mr-2" />
                  Report Item
                </Button>
              </Link>
              <Link to="/items">
                <Button size="lg" variant="outline" className="px-8 py-3">
                  <Search className="h-5 w-5 mr-2" />
                  Browse Items
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Animated Background Elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse-slow"></div>
          <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse-slow animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse-slow animation-delay-4000"></div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <Package className="h-8 w-8 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">{stats.totalItems}</div>
              <div className="text-sm text-gray-600">Total Items</div>
            </CardContent>
          </Card>
          
          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <Search className="h-8 w-8 text-red-500" />
              </div>
              <div className="text-3xl font-bold text-gray-900">{stats.lostItems}</div>
              <div className="text-sm text-gray-600">Lost Items</div>
            </CardContent>
          </Card>
          
          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="h-8 w-8 text-green-500" />
              </div>
              <div className="text-3xl font-bold text-gray-900">{stats.foundItems}</div>
              <div className="text-sm text-gray-600">Found Items</div>
            </CardContent>
          </Card>
          
          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <Users className="h-8 w-8 text-purple-500" />
              </div>
              <div className="text-3xl font-bold text-gray-900">{stats.reunited}</div>
              <div className="text-sm text-gray-600">Reunited</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Items Section */}
      {recentItems.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">Recent Reports</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recentItems.map((item) => (
              <Card key={item.id} className="glass-card hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{item.title}</CardTitle>
                    <Badge variant={item.type === 'lost' ? 'destructive' : 'default'}>
                      {item.type === 'lost' ? 'Lost' : 'Found'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4 line-clamp-2">{item.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {item.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {formatDate(item.dateReported)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link to="/items">
              <Button variant="outline">View All Items</Button>
            </Link>
          </div>
        </div>
      )}

      {/* How It Works Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Plus className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Report an Item</h3>
            <p className="text-gray-600">
              Lost something? Found something? Report it with detailed descriptions and photos.
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Smart Matching</h3>
            <p className="text-gray-600">
              Our system automatically suggests potential matches based on descriptions and locations.
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Users className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Get Reunited</h3>
            <p className="text-gray-600">
              Connect with item owners through our secure verification process.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}