import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Search, Plus, TrendingUp, Users, MapPin, Calendar } from 'lucide-react';

interface Item {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  type: 'lost' | 'found';
  dateReported: string;
  images: string[];
}

interface Stats {
  totalItems: number;
  lostItems: number;
  foundItems: number;
  reunited: number;
}

export default function HomePage() {
  const [stats, setStats] = useState<Stats>({
    totalItems: 0,
    lostItems: 0,
    foundItems: 0,
    reunited: 0
  });
  const [recentItems, setRecentItems] = useState<Item[]>([]);

  useEffect(() => {
    // Load stats from localStorage
    const savedStats = localStorage.getItem('campus_lost_found_stats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }

    // Load recent items
    const savedItems = localStorage.getItem('campus_lost_found_items');
    if (savedItems) {
      const items = JSON.parse(savedItems);
      setRecentItems(items.slice(0, 3)); // Show 3 most recent items
    }
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen pt-20 pb-12 relative">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="animate-float mb-8">
              <Package className="h-20 w-20 text-white mx-auto mb-6 animate-spin-slow" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 text-glow gradient-text">
              Campus Lost & Found
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto text-glow">
              Connecting students with their lost belongings through our smart matching system. 
              Report lost items, help others find their belongings, and build a stronger campus community.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/report">
                <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 btn-glow shimmer animate-bounce-slow">
                  <Plus className="h-5 w-5 mr-2" />
                  Report Item
                </Button>
              </Link>
              <Link to="/items">
                <Button size="lg" className="bg-white/20 text-white border-white/30 hover:bg-white/30 px-8 py-3 btn-glow backdrop-blur-sm">
                  <Search className="h-5 w-5 mr-2" />
                  Browse Items
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="glass-card text-center animate-float">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <Package className="h-8 w-8 text-blue-300 animate-pulse-slow" />
              </div>
              <div className="text-3xl font-bold text-white text-glow">{stats.totalItems}</div>
              <div className="text-sm text-white/70">Total Items</div>
            </CardContent>
          </Card>
          
          <Card className="glass-card text-center animate-float" style={{animationDelay: '0.5s'}}>
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <Search className="h-8 w-8 text-red-300 animate-pulse-slow" />
              </div>
              <div className="text-3xl font-bold text-white text-glow">{stats.lostItems}</div>
              <div className="text-sm text-white/70">Lost Items</div>
            </CardContent>
          </Card>
          
          <Card className="glass-card text-center animate-float" style={{animationDelay: '1s'}}>
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="h-8 w-8 text-green-300 animate-pulse-slow" />
              </div>
              <div className="text-3xl font-bold text-white text-glow">{stats.foundItems}</div>
              <div className="text-sm text-white/70">Found Items</div>
            </CardContent>
          </Card>
          
          <Card className="glass-card text-center animate-float" style={{animationDelay: '1.5s'}}>
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-2">
                <Users className="h-8 w-8 text-purple-300 animate-pulse-slow" />
              </div>
              <div className="text-3xl font-bold text-white text-glow">{stats.reunited}</div>
              <div className="text-sm text-white/70">Reunited</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Items Section */}
      {recentItems.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
          <h2 className="text-3xl font-bold text-white text-center mb-8 text-glow">Recent Reports</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recentItems.map((item, index) => (
              <Card key={item.id} className="glass-card hover:shadow-lg transition-all duration-300 animate-float" style={{animationDelay: `${index * 0.2}s`}}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg text-white">{item.title}</CardTitle>
                    <Badge variant={item.type === 'lost' ? 'destructive' : 'default'} className="bg-white/20 text-white border-white/30">
                      {item.type === 'lost' ? 'Lost' : 'Found'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-white/80 mb-4 line-clamp-2">{item.description}</p>
                  <div className="flex items-center justify-between text-sm text-white/60">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {item.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {formatDate(item.dateReported)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link to="/items">
              <Button className="bg-white/20 text-white border-white/30 hover:bg-white/30 btn-glow backdrop-blur-sm">
                View All Items
              </Button>
            </Link>
          </div>
        </div>
      )}

      {/* How It Works Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white text-center mb-12 text-glow">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center animate-float">
            <div className="bg-white/20 backdrop-blur-sm rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 animate-bounce-slow">
              <Plus className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-white text-glow">Report an Item</h3>
            <p className="text-white/80">
              Lost something? Found something? Report it with detailed descriptions and photos.
            </p>
          </div>
          
          <div className="text-center animate-float" style={{animationDelay: '0.5s'}}>
            <div className="bg-white/20 backdrop-blur-sm rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 animate-bounce-slow" style={{animationDelay: '1s'}}>
              <Search className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-white text-glow">Smart Matching</h3>
            <p className="text-white/80">
              Our system automatically suggests potential matches based on descriptions and locations.
            </p>
          </div>
          
          <div className="text-center animate-float" style={{animationDelay: '1s'}}>
            <div className="bg-white/20 backdrop-blur-sm rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 animate-bounce-slow" style={{animationDelay: '2s'}}>
              <Users className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-white text-glow">Get Reunited</h3>
            <p className="text-white/80">
              Connect with item owners through our secure verification process.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}