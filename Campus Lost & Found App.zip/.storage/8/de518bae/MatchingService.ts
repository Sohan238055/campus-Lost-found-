export interface Item {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  type: 'lost' | 'found';
  dateReported: string;
  images: string[];
  verificationQuestion?: string;
}

export interface MatchResult extends Item {
  matchScore: number;
  matchReasons: string[];
}

export class MatchingService {
  private static instance: MatchingService;

  static getInstance(): MatchingService {
    if (!MatchingService.instance) {
      MatchingService.instance = new MatchingService();
    }
    return MatchingService.instance;
  }

  findMatches(lostItem: Item, foundItems: Item[]): MatchResult[] {
    return foundItems
      .map(foundItem => this.calculateMatch(lostItem, foundItem))
      .filter(match => match.matchScore >= 30) // Only return matches with 30%+ score
      .sort((a, b) => b.matchScore - a.matchScore);
  }

  private calculateMatch(lostItem: Item, foundItem: Item): MatchResult {
    let score = 0;
    const reasons: string[] = [];

    // Category match (40 points)
    if (foundItem.category === lostItem.category) {
      score += 40;
      reasons.push('Same category');
    }

    // Location match (30 points)
    if (foundItem.location === lostItem.location) {
      score += 30;
      reasons.push('Same location');
    } else if (this.isNearbyLocation(lostItem.location, foundItem.location)) {
      score += 15;
      reasons.push('Nearby location');
    }

    // Title similarity (20 points)
    const titleSimilarity = this.calculateTextSimilarity(lostItem.title, foundItem.title);
    const titleScore = titleSimilarity * 20;
    score += titleScore;
    if (titleScore > 10) {
      reasons.push('Similar title');
    }

    // Description similarity (10 points)
    const descSimilarity = this.calculateTextSimilarity(lostItem.description, foundItem.description);
    const descScore = descSimilarity * 10;
    score += descScore;
    if (descScore > 5) {
      reasons.push('Similar description');
    }

    return {
      ...foundItem,
      matchScore: Math.round(score),
      matchReasons: reasons
    };
  }

  private calculateTextSimilarity(text1: string, text2: string): number {
    const words1 = text1.toLowerCase().split(/\s+/).filter(word => word.length > 2);
    const words2 = text2.toLowerCase().split(/\s+/).filter(word => word.length > 2);

    if (words1.length === 0 || words2.length === 0) return 0;

    const commonWords = words1.filter(word => 
      words2.some(word2 => 
        word2.includes(word) || 
        word.includes(word2) || 
        this.levenshteinDistance(word, word2) <= 2
      )
    );

    return commonWords.length / Math.max(words1.length, words2.length);
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));

    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;

    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1, // deletion
          matrix[j - 1][i] + 1, // insertion
          matrix[j - 1][i - 1] + indicator // substitution
        );
      }
    }

    return matrix[str2.length][str1.length];
  }

  private isNearbyLocation(location1: string, location2: string): boolean {
    const buildingMap: { [key: string]: string[] } = {
      'Library': ['Library - Main Floor', 'Library - Study Rooms'],
      'Parking': ['Parking Lot A', 'Parking Lot B'],
      'Lecture': ['Lecture Hall 1', 'Lecture Hall 2'],
    };

    for (const [building, locations] of Object.entries(buildingMap)) {
      if (locations.includes(location1) && locations.includes(location2)) {
        return true;
      }
    }

    return false;
  }
}

export default MatchingService;