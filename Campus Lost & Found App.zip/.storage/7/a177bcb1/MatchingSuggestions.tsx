import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Calendar, Package, Star } from 'lucide-react';

interface Item {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  type: 'lost' | 'found';
  dateReported: string;
  images: string[];
}

interface MatchingSuggestionsProps {
  lostItem: Item;
}

export default function MatchingSuggestions({ lostItem }: MatchingSuggestionsProps) {
  const [matches, setMatches] = useState<Array<Item & { matchScore: number }>>([]);

  useEffect(() => {
    // Get found items from localStorage
    const allItems = JSON.parse(localStorage.getItem('campus_lost_found_items') || '[]');
    const foundItems = allItems.filter((item: Item) => item.type === 'found');

    // Calculate match scores
    const matchedItems = foundItems.map((foundItem: Item) => {
      let score = 0;

      // Category match (40 points)
      if (foundItem.category === lostItem.category) {
        score += 40;
      }

      // Location match (30 points)
      if (foundItem.location === lostItem.location) {
        score += 30;
      }

      // Title similarity (20 points)
      const titleWords = lostItem.title.toLowerCase().split(' ');
      const foundTitleWords = foundItem.title.toLowerCase().split(' ');
      const commonWords = titleWords.filter(word => 
        foundTitleWords.some(foundWord => foundWord.includes(word) || word.includes(foundWord))
      );
      score += Math.min(20, (commonWords.length / titleWords.length) * 20);

      // Description similarity (10 points)
      const descWords = lostItem.description.toLowerCase().split(' ');
      const foundDescWords = foundItem.description.toLowerCase().split(' ');
      const commonDescWords = descWords.filter(word => 
        foundDescWords.some(foundWord => foundWord.includes(word) || word.includes(foundWord))
      );
      score += Math.min(10, (commonDescWords.length / descWords.length) * 10);

      return {
        ...foundItem,
        matchScore: Math.round(score)
      };
    }).filter(item => item.matchScore >= 30) // Only show items with 30%+ match
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, 3); // Show top 3 matches

    setMatches(matchedItems);
  }, [lostItem]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getMatchColor = (score: number) => {
    if (score >= 80) return 'bg-green-100 text-green-800';
    if (score >= 60) return 'bg-yellow-100 text-yellow-800';
    return 'bg-blue-100 text-blue-800';
  };

  if (matches.length === 0) {
    return (
      <Card className="glass-card">
        <CardContent className="p-8 text-center">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No Matches Found</h3>
          <p className="text-gray-600">
            We couldn't find any matching found items at the moment. Don't worry - new items are reported regularly!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">
        Potential Matches ({matches.length} found)
      </h3>
      
      <div className="grid gap-4">
        {matches.map((match) => (
          <Card key={match.id} className="glass-card hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2">{match.title}</CardTitle>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Found Item
                    </Badge>
                    <Badge variant="outline" className={getMatchColor(match.matchScore)}>
                      <Star className="h-3 w-3 mr-1" />
                      {match.matchScore}% Match
                    </Badge>
                  </div>
                </div>
                {match.images && match.images.length > 0 && (
                  <div className="ml-4 flex-shrink-0">
                    <img
                      src={match.images[0]}
                      alt={match.title}
                      className="w-16 h-16 object-cover rounded-lg"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                      }}
                    />
                  </div>
                )}
              </div>
            </CardHeader>
            
            <CardContent>
              <p className="text-gray-600 mb-4 line-clamp-2">
                {match.description}
              </p>
              
              <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {match.location}
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {formatDate(match.dateReported)}
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button size="sm" className="flex-1">
                  Contact Owner
                </Button>
                <Button size="sm" variant="outline">
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}