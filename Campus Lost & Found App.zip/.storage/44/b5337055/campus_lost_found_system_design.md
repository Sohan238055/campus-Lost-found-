# Campus Lost and Found App - System Design Document

## Implementation Approach

We will build a modern web application using React with TypeScript for type safety and maintainability. The app will use Shadcn-ui components with Tailwind CSS for consistent, responsive design. Since the requirement specifies localStorage as the backend, we'll implement a robust client-side data management system with efficient search algorithms and image handling capabilities.

**Key Technical Decisions:**
- **Frontend Framework**: React 18+ with TypeScript for component-based architecture
- **UI Library**: Shadcn-ui components with Tailwind CSS for rapid, consistent styling
- **State Management**: React Context API with useReducer for complex state operations
- **Data Storage**: localStorage with JSON serialization and base64 image encoding
- **Image Processing**: Canvas API for client-side compression and resizing
- **Search Engine**: Client-side full-text search with indexing for performance
- **Authentication**: JWT-like tokens stored in localStorage with role-based access

**Difficult Points Analysis:**
1. **localStorage Size Limitations**: Implement image compression and chunked storage
2. **Client-Side Search Performance**: Create indexed search with debounced queries
3. **Data Consistency**: Implement atomic operations and data validation
4. **Cross-Browser Compatibility**: Use polyfills and feature detection
5. **Offline Functionality**: Cache management and sync strategies

## Data Structures and Interfaces

```mermaid
classDiagram
    class User {
        +id: string
        +email: string
        +name: string
        +role: UserRole
        +contactInfo: ContactInfo
        +preferences: UserPreferences
        +createdAt: Date
        +lastLoginAt: Date
        +__init__(email: string, name: string, role: UserRole)
        +updateProfile(data: Partial<User>): void
        +validateEmail(): boolean
        +hasPermission(action: string): boolean
    }

    class ContactInfo {
        +phone?: string
        +alternateEmail?: string
        +dormRoom?: string
        +preferredContact: ContactMethod
        +__init__(preferredContact: ContactMethod)
        +isValid(): boolean
    }

    class UserPreferences {
        +notifications: NotificationSettings
        +privacy: PrivacySettings
        +language: string
        +theme: string
        +__init__()
        +updateNotifications(settings: NotificationSettings): void
    }

    class Item {
        +id: string
        +title: string
        +description: string
        +category: ItemCategory
        +type: ItemType
        +status: ItemStatus
        +location: Location
        +dateReported: Date
        +dateLostFound: Date
        +images: ItemImage[]
        +reporterId: string
        +contactInfo: ContactInfo
        +tags: string[]
        +expiresAt: Date
        +claimCount: number
        +__init__(title: string, description: string, category: ItemCategory, type: ItemType)
        +addImage(image: ItemImage): void
        +updateStatus(status: ItemStatus): void
        +isExpired(): boolean
        +generateSearchIndex(): string[]
        +validateData(): ValidationResult
    }

    class ItemImage {
        +id: string
        +data: string
        +filename: string
        +mimeType: string
        +size: number
        +compressedData?: string
        +__init__(file: File)
        +compress(quality: number): Promise<string>
        +getDisplayUrl(): string
        +isValid(): boolean
    }

    class Location {
        +building: string
        +room?: string
        +area: string
        +coordinates?: Coordinates
        +description?: string
        +__init__(building: string, area: string)
        +toString(): string
        +getDistance(other: Location): number
    }

    class Claim {
        +id: string
        +itemId: string
        +claimantId: string
        +status: ClaimStatus
        +createdAt: Date
        +updatedAt: Date
        +verificationQuestions: VerificationQuestion[]
        +responses: VerificationResponse[]
        +notes?: string
        +__init__(itemId: string, claimantId: string)
        +addVerificationQuestion(question: VerificationQuestion): void
        +submitResponse(response: VerificationResponse): void
        +approve(): void
        +reject(reason: string): void
        +isVerified(): boolean
    }

    class VerificationQuestion {
        +id: string
        +question: string
        +type: QuestionType
        +required: boolean
        +__init__(question: string, type: QuestionType)
    }

    class AuthService {
        +currentUser: User | null
        +isAuthenticated: boolean
        +__init__()
        +login(email: string, password: string): Promise<AuthResult>
        +register(userData: RegisterData): Promise<AuthResult>
        +logout(): void
        +refreshToken(): Promise<boolean>
        +validateSession(): boolean
        +hashPassword(password: string): string
    }

    class DataService {
        +storageKey: string
        +__init__(storageKey: string)
        +save<T>(key: string, data: T): void
        +load<T>(key: string): T | null
        +delete(key: string): void
        +clear(): void
        +backup(): string
        +restore(backupData: string): boolean
        +getStorageUsage(): StorageInfo
    }

    class SearchService {
        +searchIndex: SearchIndex
        +__init__()
        +indexItem(item: Item): void
        +removeFromIndex(itemId: string): void
        +search(query: SearchQuery): SearchResult[]
        +buildIndex(items: Item[]): void
        +createSearchTokens(text: string): string[]
        +calculateRelevance(item: Item, query: SearchQuery): number
    }

    class SearchQuery {
        +text?: string
        +category?: ItemCategory
        +type?: ItemType
        +location?: string
        +dateRange?: DateRange
        +status?: ItemStatus
        +sortBy: SortOption
        +sortOrder: SortOrder
        +__init__()
        +isValid(): boolean
        +toFilterFunction(): (item: Item) => boolean
    }

    class ImageService {
        +maxSize: number
        +quality: number
        +__init__(maxSize: number, quality: number)
        +compressImage(file: File): Promise<string>
        +resizeImage(imageData: string, maxWidth: number, maxHeight: number): Promise<string>
        +validateImage(file: File): ValidationResult
        +getImageDimensions(imageData: string): Promise<Dimensions>
        +convertToWebP(imageData: string): Promise<string>
    }

    class NotificationService {
        +notifications: Notification[]
        +__init__()
        +addNotification(notification: Notification): void
        +markAsRead(notificationId: string): void
        +getUnreadCount(): number
        +clearAll(): void
        +checkForMatches(item: Item): void
        +scheduleReminder(itemId: string, date: Date): void
    }

    class ItemService {
        -dataService: DataService
        -searchService: SearchService
        -notificationService: NotificationService
        +__init__(dataService: DataService, searchService: SearchService)
        +createItem(itemData: CreateItemData): Promise<Item>
        +updateItem(itemId: string, updates: Partial<Item>): Promise<Item>
        +deleteItem(itemId: string): Promise<void>
        +getItem(itemId: string): Item | null
        +getUserItems(userId: string): Item[]
        +searchItems(query: SearchQuery): SearchResult[]
        +expireOldItems(): void
        +validateItemData(data: CreateItemData): ValidationResult
    }

    class ClaimService {
        -dataService: DataService
        -notificationService: NotificationService
        +__init__(dataService: DataService, notificationService: NotificationService)
        +createClaim(claimData: CreateClaimData): Promise<Claim>
        +updateClaimStatus(claimId: string, status: ClaimStatus): Promise<void>
        +getUserClaims(userId: string): Claim[]
        +getItemClaims(itemId: string): Claim[]
        +processVerification(claimId: string, responses: VerificationResponse[]): Promise<boolean>
        +approveClaim(claimId: string): Promise<void>
        +rejectClaim(claimId: string, reason: string): Promise<void>
    }

    %% Enums
    class UserRole {
        <<enumeration>>
        STUDENT
        STAFF
        SECURITY
        ADMIN
    }

    class ItemType {
        <<enumeration>>
        LOST
        FOUND
    }

    class ItemStatus {
        <<enumeration>>
        ACTIVE
        CLAIMED
        RETURNED
        EXPIRED
        ARCHIVED
    }

    class ClaimStatus {
        <<enumeration>>
        PENDING
        VERIFIED
        APPROVED
        REJECTED
        COMPLETED
    }

    %% Relationships
    User ||--|| ContactInfo : has
    User ||--|| UserPreferences : has
    User ||--o{ Item : reports
    User ||--o{ Claim : makes
    Item ||--o{ ItemImage : contains
    Item ||--|| Location : located_at
    Item ||--o{ Claim : receives
    Claim ||--o{ VerificationQuestion : has
    Claim ||--o{ VerificationResponse : receives
    ItemService --> DataService : uses
    ItemService --> SearchService : uses
    ItemService --> NotificationService : uses
    ClaimService --> DataService : uses
    ClaimService --> NotificationService : uses
    SearchService --> Item : indexes
    AuthService --> User : manages
```

## Program Call Flow

```mermaid
sequenceDiagram
    participant U as User
    participant App as App Component
    participant Auth as AuthService
    participant IS as ItemService
    participant CS as ClaimService
    participant DS as DataService
    participant SS as SearchService
    participant ImgS as ImageService
    participant NS as NotificationService

    %% Application Initialization
    Note over U,NS: Application Startup
    U->>App: Load Application
    App->>Auth: validateSession()
    Auth->>DS: load('auth_token')
    DS-->>Auth: return token data
    Auth->>Auth: validateToken()
    Auth-->>App: return authentication status
    App->>IS: initialize()
    IS->>DS: load('items')
    DS-->>IS: return items data
    IS->>SS: buildIndex(items)
    SS-->>IS: index created
    App->>NS: initialize()
    NS->>DS: load('notifications')
    DS-->>NS: return notifications

    %% User Registration/Login
    Note over U,NS: User Authentication
    U->>App: register/login(credentials)
    App->>Auth: login(email, password)
    Auth->>Auth: hashPassword(password)
    Auth->>DS: load('users')
    DS-->>Auth: return users data
    Auth->>Auth: validateCredentials()
    Auth->>DS: save('auth_token', token)
    Auth->>DS: save('current_user', user)
    Auth-->>App: return AuthResult
    App-->>U: redirect to dashboard

    %% Report Lost/Found Item
    Note over U,NS: Item Reporting
    U->>App: reportItem(itemData)
    App->>ImgS: compressImage(photos)
    ImgS->>ImgS: resizeImage()
    ImgS->>ImgS: convertToBase64()
    ImgS-->>App: return compressed images
    App->>IS: createItem(itemData)
    IS->>IS: validateItemData()
    IS->>Item: __init__(itemData)
    Item->>Item: generateSearchIndex()
    IS->>DS: save('items', updatedItems)
    IS->>SS: indexItem(newItem)
    IS->>NS: checkForMatches(newItem)
    NS->>SS: search(matchingCriteria)
    SS-->>NS: return potential matches
    NS->>NS: addNotification(matchNotification)
    IS-->>App: return created item
    App-->>U: show success message

    %% Search Items
    Note over U,NS: Item Search
    U->>App: searchItems(searchQuery)
    App->>SS: search(query)
    SS->>SS: createSearchTokens(query.text)
    SS->>SS: toFilterFunction(query)
    SS->>SS: calculateRelevance(items, query)
    SS-->>App: return SearchResult[]
    App-->>U: display search results

    %% Claim Item
    Note over U,NS: Item Claiming
    U->>App: claimItem(itemId)
    App->>CS: createClaim(claimData)
    CS->>CS: validateClaimData()
    CS->>Claim: __init__(itemId, claimantId)
    CS->>DS: save('claims', updatedClaims)
    CS->>NS: addNotification(claimNotification)
    CS-->>App: return created claim
    App->>App: showVerificationForm()
    U->>App: submitVerification(responses)
    App->>CS: processVerification(claimId, responses)
    CS->>CS: validateResponses()
    CS->>Claim: submitResponse(responses)
    CS->>DS: save('claims', updatedClaims)
    CS-->>App: return verification result
    
    %% Claim Approval (by item owner)
    Note over U,NS: Claim Processing
    App->>CS: approveClaim(claimId)
    CS->>Claim: approve()
    CS->>IS: updateItem(itemId, {status: CLAIMED})
    IS->>DS: save('items', updatedItems)
    CS->>NS: addNotification(approvalNotification)
    CS->>DS: save('claims', updatedClaims)
    CS-->>App: return success
    App-->>U: show approval confirmation

    %% Data Management
    Note over U,NS: Background Operations
    App->>IS: expireOldItems()
    IS->>IS: checkItemExpiration()
    IS->>DS: save('items', updatedItems)
    App->>DS: getStorageUsage()
    DS-->>App: return storage info
    App->>DS: backup()
    DS-->>App: return backup data
```

## Anything UNCLEAR

1. **Campus Integration**: The PRD mentions potential integration with campus ID systems and existing student portals, but doesn't specify which systems or APIs would be available. This affects user verification and authentication design.

2. **Administrative Oversight**: While the PRD mentions campus security and staff roles, it's unclear what level of administrative control they should have over user accounts, item moderation, or data management in a localStorage-based system.

3. **Data Migration Strategy**: If the app becomes successful and needs to migrate from localStorage to a proper database, the PRD doesn't address how this transition would be handled or what compatibility requirements exist.

4. **Cross-Device Synchronization**: Since localStorage is device-specific, it's unclear how users should access their data across multiple devices (personal laptop, campus computers, mobile devices).

5. **Item Verification Standards**: The PRD doesn't specify what constitutes adequate proof of ownership for high-value items or how detailed the verification process should be for different item categories.

6. **Photo Storage Optimization**: While image compression is mentioned, specific requirements for image quality, file size limits, and storage quotas per user are not defined.

7. **Notification Delivery**: The PRD mentions notifications but doesn't clarify whether these are in-app only, browser notifications, or if email integration should be planned for future implementation.

8. **Search Performance Requirements**: No specific performance benchmarks are provided for search response times or the maximum number of items the system should handle efficiently.

9. **Privacy Compliance**: The PRD doesn't address specific privacy regulations (FERPA for educational institutions) or data retention policies that might apply to campus applications.

10. **Offline Functionality Scope**: While offline capability is listed as P1, the extent of offline functionality (read-only vs. full CRUD operations) and sync conflict resolution strategies are not specified.