import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Package, Home, Search, Plus } from 'lucide-react';

export default function Navigation() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 nav-glass shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 animate-float">
            <Package className="h-8 w-8 text-white animate-spin-slow" />
            <span className="text-xl font-bold text-white text-glow">Campus Lost & Found</span>
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/">
              <Button 
                variant={isActive('/') ? 'default' : 'ghost'} 
                className={`flex items-center gap-2 btn-glow ${
                  isActive('/') 
                    ? 'bg-white/20 text-white hover:bg-white/30' 
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                <Home className="h-4 w-4" />
                Home
              </Button>
            </Link>
            <Link to="/items">
              <Button 
                variant={isActive('/items') ? 'default' : 'ghost'} 
                className={`flex items-center gap-2 btn-glow ${
                  isActive('/items') 
                    ? 'bg-white/20 text-white hover:bg-white/30' 
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                <Search className="h-4 w-4" />
                Browse Items
              </Button>
            </Link>
            <Link to="/report">
              <Button 
                className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white btn-glow shimmer animate-bounce-slow"
              >
                <Plus className="h-4 w-4" />
                Report Item
              </Button>
            </Link>
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden flex items-center space-x-2">
            <Link to="/report">
              <Button size="sm" className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 btn-glow animate-bounce-slow">
                <Plus className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}