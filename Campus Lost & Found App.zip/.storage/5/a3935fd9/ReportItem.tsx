import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Upload, MapPin, Package, CheckCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import MatchingSuggestions from '@/components/MatchingSuggestions';

interface FormData {
  type: 'lost' | 'found';
  title: string;
  description: string;
  category: string;
  location: string;
  verificationQuestion: string;
  images: string[];
}

interface SubmittedItem extends FormData {
  id: string;
  dateReported: string;
  status: string;
  reportedBy: string;
  contactInfo: string;
}

const categories = [
  { value: 'electronics', label: '📱 Electronics', emoji: '📱' },
  { value: 'bags', label: '🎒 Bags & Backpacks', emoji: '🎒' },
  { value: 'books', label: '📚 Books & Notebooks', emoji: '📚' },
  { value: 'accessories', label: '👓 Accessories', emoji: '👓' },
  { value: 'clothing', label: '👕 Clothing', emoji: '👕' },
  { value: 'keys', label: '🔑 Keys & Cards', emoji: '🔑' },
  { value: 'sports', label: '⚽ Sports Equipment', emoji: '⚽' },
  { value: 'other', label: '📦 Other', emoji: '📦' }
];

const locations = [
  'Library - Main Floor',
  'Library - Study Rooms',
  'Cafeteria',
  'Student Center',
  'Gymnasium',
  'Computer Lab',
  'Parking Lot A',
  'Parking Lot B',
  'Lecture Hall 1',
  'Lecture Hall 2',
  'Science Building',
  'Engineering Building',
  'Arts Building',
  'Dormitory Common Area',
  'Campus Quad',
  'Other'
];

export default function ReportItem() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    type: 'lost',
    title: '',
    description: '',
    category: '',
    location: '',
    verificationQuestion: '',
    images: []
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showMatches, setShowMatches] = useState(false);
  const [submittedItem, setSubmittedItem] = useState<SubmittedItem | null>(null);

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setFormData(prev => ({
          ...prev,
          images: [...prev.images, result]
        }));
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const validateForm = (): boolean => {
    if (!formData.title.trim()) {
      toast.error('Please enter a title for the item');
      return false;
    }
    if (!formData.description.trim()) {
      toast.error('Please enter a description');
      return false;
    }
    if (!formData.category) {
      toast.error('Please select a category');
      return false;
    }
    if (!formData.location) {
      toast.error('Please select a location');
      return false;
    }
    if (formData.type === 'lost' && !formData.verificationQuestion.trim()) {
      toast.error('Please enter a verification question for lost items');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      // Create item object with all lost item details
      const newItem: SubmittedItem = {
        ...formData,
        id: Date.now().toString(),
        dateReported: new Date().toISOString(),
        status: 'active',
        reportedBy: 'Anonymous User',
        contactInfo: 'Contact via campus security'
      };

      // Get existing items from localStorage
      const existingItems = JSON.parse(localStorage.getItem('campus_lost_found_items') || '[]');
      
      // Add new item to the beginning of the array (most recent first)
      const updatedItems = [newItem, ...existingItems];
      
      // Save to localStorage
      localStorage.setItem('campus_lost_found_items', JSON.stringify(updatedItems));

      // Update stats
      const stats = JSON.parse(localStorage.getItem('campus_lost_found_stats') || '{}');
      const updatedStats = {
        ...stats,
        totalItems: updatedItems.length,
        lostItems: updatedItems.filter(item => item.type === 'lost').length,
        foundItems: updatedItems.filter(item => item.type === 'found').length
      };
      localStorage.setItem('campus_lost_found_stats', JSON.stringify(updatedStats));

      // Show success message
      const itemTypeText = formData.type === 'lost' ? 'Lost' : 'Found';
      toast.success(`${itemTypeText} item "${formData.title}" reported successfully!`);

      // Set submitted item and show matches if it's a lost item
      setSubmittedItem(newItem);
      
      if (formData.type === 'lost') {
        setShowMatches(true);
        toast.info('Searching for potential matches...');
      } else {
        // For found items, redirect after a short delay
        setTimeout(() => {
          navigate('/items');
        }, 2000);
      }

    } catch (error) {
      console.error('Error submitting item:', error);
      toast.error('Failed to submit item. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      type: 'lost',
      title: '',
      description: '',
      category: '',
      location: '',
      verificationQuestion: '',
      images: []
    });
    setShowMatches(false);
    setSubmittedItem(null);
  };

  const selectedCategory = categories.find(cat => cat.value === formData.category);

  if (showMatches && submittedItem) {
    return (
      <div className="min-h-screen pt-20 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Lost Item Reported Successfully!</h1>
            <p className="text-gray-600 mb-4">
              Your lost item "<strong>{submittedItem.title}</strong>" has been added to our database.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <h3 className="font-semibold text-blue-900 mb-2">Item Details Captured:</h3>
              <div className="text-left text-sm text-blue-800">
                <p><strong>Title:</strong> {submittedItem.title}</p>
                <p><strong>Category:</strong> {selectedCategory?.label}</p>
                <p><strong>Location:</strong> {submittedItem.location}</p>
                <p><strong>Description:</strong> {submittedItem.description}</p>
                <p><strong>Verification Question:</strong> {submittedItem.verificationQuestion}</p>
                <p><strong>Images:</strong> {submittedItem.images.length} uploaded</p>
              </div>
            </div>
            <p className="text-gray-600">
              Here are some potential matches from found items:
            </p>
          </div>

          <MatchingSuggestions lostItem={submittedItem} />

          <div className="text-center mt-8 space-y-4">
            <Button onClick={() => navigate('/items')} className="mr-4">
              View All Items
            </Button>
            <Button variant="outline" onClick={resetForm}>
              Report Another Item
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <Package className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Report an Item</h1>
          <p className="text-gray-600">
            Help reunite lost items with their owners or report something you found
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Item Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Item Type */}
              <div>
                <Label className="text-base font-medium">Item Type</Label>
                <RadioGroup
                  value={formData.type}
                  onValueChange={(value) => handleInputChange('type', value as 'lost' | 'found')}
                  className="flex gap-6 mt-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="lost" id="lost" />
                    <Label htmlFor="lost" className="flex items-center gap-2 cursor-pointer">
                      <AlertCircle className="h-4 w-4 text-red-500" />
                      I Lost Something
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="found" id="found" />
                    <Label htmlFor="found" className="flex items-center gap-2 cursor-pointer">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      I Found Something
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Title */}
              <div>
                <Label htmlFor="title">Item Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  placeholder="e.g., Black iPhone 13, Blue backpack, Red wallet, etc."
                  required
                />
              </div>

              {/* Category */}
              <div>
                <Label>Category *</Label>
                <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category">
                      {selectedCategory && (
                        <span className="flex items-center gap-2">
                          <span>{selectedCategory.emoji}</span>
                          {selectedCategory.label}
                        </span>
                      )}
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        <span className="flex items-center gap-2">
                          <span>{category.emoji}</span>
                          {category.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Provide detailed description including color, brand, size, distinctive features, when and where you lost it..."
                  rows={4}
                  required
                />
              </div>

              {/* Location */}
              <div>
                <Label>Location *</Label>
                <Select value={formData.location} onValueChange={(value) => handleInputChange('location', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Where was it lost/found?">
                      {formData.location && (
                        <span className="flex items-center gap-2">
                          <MapPin className="h-4 w-4" />
                          {formData.location}
                        </span>
                      )}
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((location) => (
                      <SelectItem key={location} value={location}>
                        <span className="flex items-center gap-2">
                          <MapPin className="h-4 w-4" />
                          {location}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Verification Question (only for lost items) */}
              {formData.type === 'lost' && (
                <div>
                  <Label htmlFor="verification">Verification Question *</Label>
                  <Input
                    id="verification"
                    value={formData.verificationQuestion}
                    onChange={(e) => handleInputChange('verificationQuestion', e.target.value)}
                    placeholder="e.g., What color is the case? What's written on the cover? What's inside the wallet?"
                    required
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    This question will be asked to verify ownership when someone claims this item.
                  </p>
                </div>
              )}

              {/* Image Upload */}
              <div>
                <Label>Images</Label>
                <div className="mt-2">
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-8 h-8 mb-4 text-gray-500" />
                        <p className="mb-2 text-sm text-gray-500">
                          <span className="font-semibold">Click to upload</span> or drag and drop
                        </p>
                        <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                      </div>
                      <input
                        type="file"
                        className="hidden"
                        multiple
                        accept="image/*"
                        onChange={handleImageUpload}
                      />
                    </label>
                  </div>
                </div>

                {/* Image Preview */}
                {formData.images.length > 0 && (
                  <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                    {formData.images.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image}
                          alt={`Upload ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <div className="flex gap-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {isSubmitting ? 'Submitting...' : `Report ${formData.type === 'lost' ? 'Lost' : 'Found'} Item`}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/')}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}